
const express = require("express");
const router = express.Router();
const patientController = require("../controller/patient.controller");
router.get("/view", patientController.getPatientDetails);
router.get("/view/:id", patientController.getPatientDetailsByID);
router.post("/save", patientController.addpatientDetails);
router.put("/update/:id", patientController.updatepatientDetails);

module.exports = router;