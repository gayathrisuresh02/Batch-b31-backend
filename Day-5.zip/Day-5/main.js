const express = require("express");
const app = express();
app.use(express.json());
const patientRouter=require("./router/patient.router")
app.use(patientRouter);
const port = 8080;
app.listen(port, () => {
    console.log(`${port} server running successfully`)
})