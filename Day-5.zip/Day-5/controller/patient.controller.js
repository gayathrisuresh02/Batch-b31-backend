const patientModel = require("../model/patient.model");

const getPatientDetails = (req, res) => {
    if (patientModel.length == "")
    {
      return   res.status(400).json({message:"patient data not available"})
    }
    return res.status(200).json(patientModel);
}

const getPatientDetailsByID = (req, res) => {
    const id = req.params.id;

    const searchPatient=patientModel.find(data=>data.id==id)
  if (!searchPatient) {
    return res.status(400).json({ message: "patient data not available" });
  }
  return res.status(200).json(searchPatient);
};

const addpatientDetails = (req, res) => {
    const { pname, age, address } = req.body;

    if (pname == "" || age == "" || address == "")
    {
        return res.status(404).json({message:"patient details missing"})
    }
 

    const patient = {
        id: Date.now(),
        pname,
        age,
        address
    }
    patientModel.push(patient);
    return res
      .status(201)
      .json({ message: "patient data added", patientModel });
}

const updatepatientDetails = (req, res) => {
    const id = req.params.id;
    const searchPatient = patientModel.find((data) => data.id == id);
    const {pname,age,address}=req.body
    if (!searchPatient)
    {
        return res.status(404).json({message:"patient details not found"})
    }

    searchPatient.pname = pname || searchPatient.pname;
    searchPatient.age = age || searchPatient.age;
    searchPatient.address = address || searchPatient.pname;

 return res.status(201).json({message:"patient details update",patientModel})

}
module.exports = { getPatientDetails,getPatientDetailsByID,addpatientDetails,updatepatientDetails };